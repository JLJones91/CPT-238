$(document).ready(function() {
	$(".name") .addClass("formal");
});

$(document).ready(function() {
	$(".books") .addClass("list");
});
